<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
    <div class="container">
        <h2 class="text-2xl font-bold text-white mb-4">Subscriptions View</h2>

        <!-- Search and Filters -->
        <div class="bg-gray-800 p-6 rounded-lg shadow-md mb-6">
            <!-- Search Input -->
            <form id="searchForm" action="<?php echo e(route('contacts.index')); ?>" method="GET" class="mb-6">
                <div class="flex items-center gap-4">
                    <input type="text" name="search" placeholder="Search by name, email, or phone" value="<?php echo e(request('search')); ?>" class="px-4 py-2 rounded-lg bg-gray-700 text-white w-full">
                    <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg">Search</button>
                    <a href="<?php echo e(route('contacts.index')); ?>" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg">Reset</a>
                </div>
            </form>

            <!-- Filters -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Sort by Created At (DSC) -->
                <select name="sort" class="px-4 py-2 rounded-lg bg-gray-700 text-white w-full" form="searchForm">
                    <option value="">Sort By</option>
                    <option value="desc" <?php echo e(request('sort') == 'desc' ? 'selected' : ''); ?>>Newest First</option>
                    <option value="asc" <?php echo e(request('sort') == 'asc' ? 'selected' : ''); ?>>Oldest First</option>
                </select>
                <!-- Filter by Subject -->
                <select name="subject" class="px-4 py-2 rounded-lg bg-gray-700 text-white w-full" form="searchForm">
                    <option value="">All Subjects</option>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject); ?>" <?php echo e(request('subject') == $subject ? 'selected' : ''); ?>><?php echo e($subject); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <!-- Table -->
        <table class="min-w-full table-auto text-white bg-gray-800 shadow-md rounded-lg">
            <thead class="bg-gray-900">
                <tr>
                    <th class="px-4 py-2">Name</th>
                    <th class="px-4 py-2">Email</th>
                    <th class="px-4 py-2">Phone</th>
                    <th class="px-4 py-2">Subject</th>
                    <th class="px-4 py-2">Message</th>
                    <th class="px-4 py-2">Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-gray-700 border-b border-gray-600">
                    <td class="px-4 py-2"><?php echo e($contact->name); ?></td>
                    <td class="px-4 py-2"><?php echo e($contact->email); ?></td>
                    <td class="px-4 py-2"><?php echo e($contact->phone); ?></td>
                    <td class="px-4 py-2"><?php echo e($contact->subject); ?></td>
                    <td class="px-4 py-2"><?php echo e($contact->message); ?></td>
                    <td class="px-4 py-2"><?php echo e($contact->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Pagination Links -->
        <div class="mt-6">
            <?php echo e($contacts->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH D:\Work Place\activity\test\resources\views/contacts/index.blade.php ENDPATH**/ ?>